// React component for an interactive curriculum map with colorful years and Disney typography
import React, { useState } from "react";

const yearColors = [
  "bg-pink-100", "bg-purple-100", "bg-blue-100", "bg-yellow-100", "bg-green-100",
  "bg-red-100", "bg-orange-100", "bg-teal-100", "bg-lime-100", "bg-fuchsia-100", "bg-rose-100"
];

const curriculum = [/* ... misma estructura existente ... */];

export default function CurriculumMap() {
  const [hovered, setHovered] = useState(null);
  const [filter, setFilter] = useState("Todos");
  const types = ["Todos", "Básica", "Clínica", "Quirúrgica", "Ética", "General"];

  return (
    <div className="p-4 font-[cursive]">
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Waltograph&display=swap'); body { font-family: 'Waltograph', cursive; }`}</style>

      <div className="mb-4">
        <label className="mr-2 font-semibold text-lg">Filtrar por tipo:</label>
        <select
          className="p-2 border rounded"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          {types.map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {curriculum.map((sem, index) => (
          <div
            key={index}
            className={`${yearColors[index % yearColors.length]} rounded-2xl shadow-md p-4 border border-gray-300`}
          >
            <h2 className="text-2xl font-bold mb-2 text-pink-800 drop-shadow-md">{sem.semester}</h2>
            <ul className="list-disc pl-5 text-black">
              {sem.subjects
                .filter((subject) => filter === "Todos" || subject.type === filter)
                .map((subject, i) => (
                  <li
                    key={i}
                    className={`relative group cursor-help transition-colors duration-300 ${
                      subject.type === "Básica"
                        ? "text-blue-700"
                        : subject.type === "Clínica"
                        ? "text-red-700"
                        : subject.type === "Quirúrgica"
                        ? "text-yellow-700"
                        : subject.type === "Ética"
                        ? "text-purple-700"
                        : "text-gray-800"
                    }`}
                    onMouseEnter={() => setHovered(subject)}
                    onMouseLeave={() => setHovered(null)}
                  >
                    {subject.name}
                    {hovered === subject && subject.prerequisites.length > 0 && (
                      <div className="absolute z-10 w-64 bg-black text-white text-sm rounded p-2 top-full left-0 mt-1 shadow-xl">
                        Prerrequisitos: {subject.prerequisites.join(", ")}
                      </div>
                    )}
                  </li>
                ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
